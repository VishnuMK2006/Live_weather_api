//api call        
function apicall() {
    const locat = document.getElementById("location");
    const img = document.getElementById("img");
    const condition = document.getElementById("condition");
    const feels = document.getElementById("feels");
    const speed = document.getElementById("speed");
    const humidity = document.getElementById("humidity");
    const pressure = document.getElementById("pressure");
    const temp=document.getElementById("cur");
    const state = document.getElementById("city").value;
    const measure = document.getElementById("unit").value;
    const api_url = `http://api.weatherstack.com/current?access_key=<--replace with your key-->&query=${state}&units=${measure}`;

    fetch(api_url)
        .then((args) => args.json())
        .then((report) => {
            if (!locat || !img || !condition || !feels || !speed || !humidity || !pressure ||!temp) {
                console.error("Some elements are missing in the DOM.");
                return;
            }

            let v1 = report["location"].name;
            let v2 = report["current"].weather_descriptions[0];
            let v3 = report["current"].feelslike;
            let v4 = report["current"].wind_speed;
            let v5 = report["current"].humidity;
            let v6 = report["current"].pressure;
            let v7 = report["current"].weather_icons[0];
            let v8 = report["current"].temperature;
           if(measure=="f")
            temp.innerHTML=`${v8}°F`;
           else
           temp.innerHTML=`${v8}°C`;
            locat.innerHTML = `${v1}`;
            condition.innerHTML = `<span>Condition:</span> ${v2}`;
            if(measure=="f")
                feels.innerHTML = `<span>Feels Like:</span> ${v3}°F`;
            else
            feels.innerHTML = `<span>Feels Like:</span> ${v3}°C`;
            speed.innerHTML = `<span>Wind Speed:</span> ${v4}km/h`;
            humidity.innerHTML = `<span>Humidity:</span> ${v5}%`;
            pressure.innerHTML = `<span>Pressure:</span> ${v6}hPa`;
            img.innerHTML = `<img src="${v7}" alt="Weather Icon" style="border-radius: 12px;">`;
        })
        .catch((error) => {
            console.error("Error fetching weather data:", error);
        });
}


 //api call end
 
 //pop-up edit
 
 function populateStates() {
     const country = document.getElementById("country").value;
     const state = document.getElementById("state");
     const city = document.getElementById("city");
     city.innerHTML = `<option disabled selected>Select City</option>`; // Reset City dropdown
     
     if (country === "India") {
         state.innerHTML = `
             <option disabled selected>Select State</option>
             <option value="Tamil Nadu">Tamil Nadu</option>
             <option value="Other">No Data</option>
         `;
     } else {
         state.innerHTML = `<option disabled selected>No Data</option>`;
     }
 }
 
 function populateCities() {
     const state = document.getElementById("state").value;
     const city = document.getElementById("city");
     
     if (state === "Tamil Nadu") {
         city.innerHTML = `
                 <option disabled selected>Select City</option>
                 <option value="Arcot">Arcot</option>
                 <option value="Chengalpattu">Chengalpattu</option>
                 <option value="Chennai">Chennai</option>
                 <option value="Chidambaram">Chidambaram</option>
                 <option value="Coimbatore">Coimbatore</option>
                 <option value="Cuddalore">Cuddalore</option>
                 <option value="Dharmapuri">Dharmapuri</option>
                 <option value="Dindigul">Dindigul</option>
                 <option value="Erode">Erode</option>
                 <option value="Kanchipuram">Kanchipuram</option>
                 <option value="Kanniyakumari">Kanniyakumari</option>
                 <option value="Kodaikanal">Kodaikanal</option>
                 <option value="Kumbakonam">Kumbakonam</option>
                 <option value="Madurai">Madurai</option>
                 <option value="Mamallapuram">Mamallapuram</option>
                 <option value="Nagappattinam">Nagappattinam</option>
                 <option value="Nagercoil">Nagercoil</option>
                 <option value="Palayamkottai">Palayamkottai</option>
                 <option value="Pudukkottai">Pudukkottai</option>
                 <option value="Rajapalayam">Rajapalayam</option>
                 <option value="Ramanathapuram">Ramanathapuram</option>
                 <option value="Salem">Salem</option>
                 <option value="Thanjavur">Thanjavur</option>
                 <option value="Tiruchchirappalli">Tiruchchirappalli</option>
                 <option value="Tirunelveli">Tirunelveli</option>
                 <option value="Tiruppur">Tiruppur</option>
                 <option value="Thoothukudi">Thoothukudi</option>
                 <option value="Udhagamandalam">Udhagamandalam</option>
                 <option value="Vellore">Vellore</option>
         `;
     } else {
         city.innerHTML = `<option disabled selected>No Data</option>`;
     }
 }
 
 //pop-up edit
 